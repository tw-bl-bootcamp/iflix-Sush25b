package com.thoughtworks.iflix;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IflixApplication {

	public static void main(String[] args) {
		SpringApplication.run(IflixApplication.class, args);
	}

}
